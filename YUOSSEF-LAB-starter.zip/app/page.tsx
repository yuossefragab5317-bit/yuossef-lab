"use client";

import { useEffect, useState } from "react";
import { ArrowUpRight, Code2, Github, Globe2, Layers3, Mail, Sparkles } from "lucide-react";
import { supabase } from "@/lib/supabase";

type Project = {
  id: string;
  title_en: string;
  title_ar: string;
  description_en: string;
  description_ar: string;
  category: string;
  image_url: string | null;
  demo_url: string | null;
  github_url: string | null;
};

const copy = {
  en: {
    navProjects: "Projects", navAbout: "About", navContact: "Contact",
    eyebrow: "INDEPENDENT DIGITAL STUDIO",
    titleA: "Ideas become", titleB: "reality.",
    intro: "I build digital experiences, useful applications and creative websites — one project at a time.",
    explore: "Explore projects", about: "A little about me",
    selected: "SELECTED WORK", heading: "Things I've built.", sub: "A collection of experiments, ideas and products brought to life.",
    empty: "Your projects will appear here soon.", setup: "Connect Supabase and add your first project from the dashboard.",
    aboutLabel: "BEHIND THE LAB", aboutTitle: "Curiosity drives the code.",
    aboutText: "YUOSSEF LAB is my personal space for building and sharing digital projects. Every idea is a chance to learn, experiment and make something useful.",
    contact: "HAVE AN IDEA?", contactTitle: "Let's build something.", contactText: "Have a project, suggestion or collaboration in mind? I'd love to hear about it.",
    email: "Get in touch", footer: "Designed & built with curiosity."
  },
  ar: {
    navProjects: "المشاريع", navAbout: "عني", navContact: "تواصل",
    eyebrow: "استوديو رقمي مستقل",
    titleA: "أفكار تتحول إلى", titleB: "واقع.",
    intro: "أصمم تجارب رقمية وتطبيقات مفيدة ومواقع إبداعية — مشروعًا بعد الآخر.",
    explore: "استكشف المشاريع", about: "تعرف عليّ",
    selected: "أعمال مختارة", heading: "مشاريع صنعتها.", sub: "مجموعة من التجارب والأفكار والمشروعات التي تحولت إلى واقع.",
    empty: "مشاريعك هتظهر هنا قريبًا.", setup: "اربط Supabase وأضف أول مشروع من لوحة التحكم.",
    aboutLabel: "وراء المعمل", aboutTitle: "الفضول هو محرك الإبداع.",
    aboutText: "YUOSSEF LAB هي مساحتي الشخصية لبناء ومشاركة المشاريع الرقمية. كل فكرة فرصة للتعلم والتجربة وصناعة شيء مفيد.",
    contact: "لديك فكرة؟", contactTitle: "دعنا نصنع شيئًا مميزًا.", contactText: "عندك مشروع أو اقتراح أو حابب تتعاون؟ يسعدني أسمع منك.",
    email: "تواصل معي", footer: "صُنع بالشغف وحب التجربة."
  }
};

export default function Home() {
  const [lang, setLang] = useState<"en" | "ar">("en");
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const t = copy[lang];

  useEffect(() => {
    async function load() {
      if (!supabase) { setLoading(false); return; }
      const { data } = await supabase.from("projects").select("*").eq("published", true).order("created_at", { ascending: false });
      setProjects((data as Project[]) || []);
      setLoading(false);
    }
    load();
  }, []);

  return (
    <main dir={lang === "ar" ? "rtl" : "ltr"}>
      <div className="site-shell">
        <header className="topbar">
          <a className="brand" href="#"><span className="brand-mark">Y</span><span>YUOSSEF<span className="blue">.</span><small>LAB</small></span></a>
          <nav>
            <a href="#projects">{t.navProjects}</a><a href="#about">{t.navAbout}</a><a href="#contact">{t.navContact}</a>
          </nav>
          <button className="lang-button" onClick={() => setLang(lang === "en" ? "ar" : "en")}><Globe2 size={16}/>{lang === "en" ? "العربية" : "English"}</button>
        </header>

        <section className="hero">
          <div className="hero-glow" />
          <div className="hero-copy">
            <div className="eyebrow"><span className="pulse" />{t.eyebrow}</div>
            <h1>{t.titleA}<br/><span>{t.titleB}</span></h1>
            <p>{t.intro}</p>
            <div className="hero-actions">
              <a className="button-primary" href="#projects">{t.explore}<ArrowUpRight size={17}/></a>
              <a className="button-quiet" href="#about">{t.about}</a>
            </div>
            <div className="hero-meta"><span><Code2 size={15}/> CODE WITH PURPOSE</span><span><Sparkles size={15}/> BUILT TO EXPLORE</span></div>
          </div>
          <div className="hero-art" aria-label="Abstract YUOSSEF LAB graphic">
            <div className="orbit orbit-one"/><div className="orbit orbit-two"/>
            <div className="art-card"><span className="art-kicker">YUOSSEF LAB / 001</span><div className="art-symbol">Y<span>.</span></div><div className="art-bottom"><span>DIGITAL<br/>EXPERIENCES</span><Layers3 size={25}/></div></div>
            <div className="float-tag tag-top">CREATIVE CODE ↗</div><div className="float-tag tag-bottom">EST. 2026</div>
          </div>
        </section>

        <section className="projects section" id="projects">
          <div className="section-top"><div><div className="eyebrow">{t.selected}</div><h2>{t.heading}</h2><p>{t.sub}</p></div><span className="section-index">01 / WORK</span></div>
          {loading ? <div className="empty-state">Loading projects...</div> : projects.length === 0 ? (
            <div className="empty-state"><div className="empty-icon"><Layers3 size={24}/></div><h3>{t.empty}</h3><p>{t.setup}</p><a href="/admin" className="text-link">Open dashboard <ArrowUpRight size={15}/></a></div>
          ) : <div className="project-grid">{projects.map((p) => <article className="project-card" key={p.id}>
            <div className="project-image">{p.image_url ? <img src={p.image_url} alt={lang === "ar" ? p.title_ar : p.title_en}/> : <div className="image-placeholder"><Code2 size={34}/></div>}<span>{p.category}</span></div>
            <div className="project-info"><h3>{lang === "ar" ? p.title_ar : p.title_en}</h3><p>{lang === "ar" ? p.description_ar : p.description_en}</p><div className="project-links">{p.demo_url && <a href={p.demo_url} target="_blank" rel="noreferrer">Live demo <ArrowUpRight size={14}/></a>}{p.github_url && <a href={p.github_url} target="_blank" rel="noreferrer"><Github size={14}/> Source</a>}</div></div>
          </article>)}</div>}
        </section>

        <section className="about section" id="about"><div className="about-symbol">Y<span>.</span></div><div><div className="eyebrow">{t.aboutLabel}</div><h2>{t.aboutTitle}</h2><p>{t.aboutText}</p><div className="skill-row"><span>WEB DEVELOPMENT</span><span>CREATIVE THINKING</span><span>PROBLEM SOLVING</span></div></div></section>

        <section className="contact section" id="contact"><div><div className="eyebrow">{t.contact}</div><h2>{t.contactTitle}</h2><p>{t.contactText}</p></div><a className="button-primary" href="mailto:hello@yuosseflab.com">{t.email}<Mail size={17}/></a></section>
        <footer><a className="brand" href="#"><span className="brand-mark">Y</span><span>YUOSSEF<span className="blue">.</span><small>LAB</small></span></a><span>© 2026 YUOSSEF LAB</span><span>{t.footer}</span></footer>
      </div>
    </main>
  );
}
